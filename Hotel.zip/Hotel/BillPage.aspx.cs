﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel
{
    public partial class BillPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the session variable contains a valid bill_id
                if (Session["BILL"] != null && int.TryParse(Session["BILL"].ToString(), out int billId))
                {
                    // Fetch and display billing details
                    DisplayBillingDetails(billId);
                }
                else
                {
                    // Handle the case when the session variable is not set or not valid
                    lblBillDetails.Text = "Invalid billing details.";
                }
            }
        }

        private void DisplayBillingDetails(int billId)
        {
            // Fetch billing details from the Bill table based on bill_id
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Hotel\App_Data\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Bill WHERE bill_id = @BillId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@BillId", billId);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    // Display billing details in the label or any other control
                    lblBillDetails.Text = $"Bill ID: {reader["bill_id"]}<br/>" +
                                          $"Bill Price: {reader["bill_price"]}<br/>" +
                                          $"Reservation ID: {reader["reservation_id"]}";
                }
                else
                {
                    // Handle the case when the billing details are not found
                    lblBillDetails.Text = "Billing details not found.";
                }
            }
        }
    }
}