﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void loginButton_Click(object sender, EventArgs e)
        {
            string enteredIdentifier = mail.Text.Trim();  // This can be either email or username
            string enteredPassword = pass.Text.Trim();

            // Check if the entered email or username and password match a record in the database
            if (IsLoginValid(enteredIdentifier, enteredPassword))
            {
                if (Session["UserRole"].ToString() == "receptionist")
                {
                    Response.Redirect("STAFF.aspx");
                }
                Response.Redirect("WebForm1");
            }
            else
            {
                string script = "alert('Invalid email or username or password. Please try again.');";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", script, true);
            }
        }

        private bool IsLoginValid(string enteredIdentifier, string enteredPassword)
        {
            // Replace "YourConnectionString" with your actual database connection string
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                enteredPassword = HashPassword(enteredPassword);
                string query = "SELECT COUNT(*) FROM Users WHERE (user_email = @enteredIdentifier OR username = @enteredIdentifier) AND user_password = @enteredPassword";
                string query2 = "SELECT username, user_role FROM Users WHERE user_email = @userEmail";
                Session["UserRole"] = "customer";
                using (SqlCommand command = new SqlCommand(query2, connection))
                {
                    if (enteredIdentifier.Contains('@'))
                    {
                        command.Parameters.AddWithValue("@userEmail", enteredIdentifier);
                        SqlDataReader reader = command.ExecuteReader();
                        // Execute the query and get the result
                        if (reader.Read())
                        {
                            Session["Username"] = reader["username"].ToString();
                            Session["UserRole"] = reader["user_role"];
                        }
                        reader.Close();
                    }
                    else
                    {
                        Session["Username"] = enteredIdentifier;
                    }
                }
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to the query
                    command.Parameters.AddWithValue("@enteredIdentifier", enteredIdentifier);
                    command.Parameters.AddWithValue("@enteredPassword", enteredPassword);

                    // Execute the query and get the result
                    int count = (int)command.ExecuteScalar();

                    // If count is 1, the email or username and password match a record in the database
                    return count == 1;
                }
            }
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                // Convert the password string to bytes
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);

                // Compute the hash
                byte[] hashBytes = sha256.ComputeHash(passwordBytes);

                // Convert the hash to a string representation (hex)
                string hashedPassword = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();

                return hashedPassword;
            }
        }

    }
}