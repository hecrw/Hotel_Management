﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel
{
    public partial class ratings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private void UpdateAverageRating(int newRating)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Fetch existing data
                string fetchDataQuery = "SELECT rating_number, average_rating FROM [dbo].[Report]";
                SqlCommand fetchDataCommand = new SqlCommand(fetchDataQuery, connection);

                int currentRatingNumbers = 0;
                double currentAverageRating = 0;

                using (SqlDataReader reader = fetchDataCommand.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        currentRatingNumbers = Convert.ToInt32(reader["rating_number"]);
                        currentAverageRating = Convert.ToDouble(reader["average_rating"]);
                    }
                }

                // Calculate new average
                double newAverageRating = ((currentAverageRating * currentRatingNumbers) + newRating) / (currentRatingNumbers + 1);

                // Update database with new values using a separate connection and command
                using (SqlConnection updateConnection = new SqlConnection(connectionString))
                {
                    updateConnection.Open();

                    string updateQuery = "UPDATE [dbo].[Report] SET rating_number = @ratingNumbers, average_rating = @averageRating";
                    SqlCommand updateCommand = new SqlCommand(updateQuery, updateConnection);
                    updateCommand.Parameters.AddWithValue("@ratingNumbers", currentRatingNumbers + 1);
                    updateCommand.Parameters.AddWithValue("@averageRating", newAverageRating);

                    updateCommand.ExecuteNonQuery();
                }
            }
        }



        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int selectedRating = Convert.ToInt32(ratingList.SelectedValue);
            UpdateAverageRating(selectedRating);
            lblMessage.Text = "Thank you for your rating!";

        }
    }
}