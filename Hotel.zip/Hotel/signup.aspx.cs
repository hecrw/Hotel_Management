﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel
{
    public partial class signup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void signupButton_Click(object sender, EventArgs e)
        {
            string name = Name.Text.Trim();
            string username = user.Text.Trim();
            string email = mail.Text.Trim();
            string password = pass.Text.Trim();

            // Check if the username is unique
            if (IsUsernameUnique(username))
            {
                if (IsEmailUnique(email))
                {
                    // Hash the password (for security) - make sure to use a secure hashing algorithm
                    string hashedPassword = HashPassword(password);

                    // Insert user data into the database
                    InsertUserData(username, name, email, hashedPassword, "customer");
                    Session["Username"] = username;
                    Response.Redirect("WebForm1");
                }
                else
                {
                    // Email is not unique, show a popup
                    string script = "alert('Email is already associated with another account. Please use a different email.');";
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", script, true);
                }
            }
            else
            {
                string script = "alert('Username already exists. Please choose another one.');";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", script, true);
            }
        }
        private bool IsUsernameUnique(string username)
        {
            // Assuming you are using SqlConnection and SqlCommand for database interaction

            // Replace "YourConnectionString" with your actual database connection string
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Prepare the SQL query with a parameterized query to prevent SQL injection
                string query = "SELECT COUNT(*) FROM Users WHERE username = @username";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to the query
                    command.Parameters.AddWithValue("@username", username);

                    // Execute the query and get the result
                    int count = (int)command.ExecuteScalar();

                    // If count is 0, the username is unique; otherwise, it's not
                    return count == 0;
                }
            }
        }
        private void InsertUserData(string username, string name,string email, string password, string role)
        {
            // Replace "YourConnectionString" with your actual database connection string
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Prepare the SQL query for insertion
                string query = "INSERT INTO Users (username,name ,user_email, user_password, user_role) VALUES (@username,@name ,@email, @password, @role)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to the query
                    command.Parameters.AddWithValue("name", name);
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@password", password);
                    command.Parameters.AddWithValue("@role", role);

                    // Execute the query
                    command.ExecuteNonQuery();
                }
            }
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                // Convert the password string to bytes
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);

                // Compute the hash
                byte[] hashBytes = sha256.ComputeHash(passwordBytes);

                // Convert the hash to a string representation (hex)
                string hashedPassword = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();

                return hashedPassword;
            }
        }
        private bool IsEmailUnique(string email)
        {
            // Replace "YourConnectionString" with your actual database connection string
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Prepare the SQL query with a parameterized query to prevent SQL injection
                string query = "SELECT COUNT(*) FROM Users WHERE user_email = @email";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to the query
                    command.Parameters.AddWithValue("@email", email);

                    // Execute the query and get the result
                    int count = (int)command.ExecuteScalar();

                    // If count is 0, the email is unique; otherwise, it's not
                    return count == 0;
                }
            }
        }
    }
}