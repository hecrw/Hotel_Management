﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel
{
    public partial class STAFF : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindReservationData();
            }
        }
        private void BindReservationData()
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Hotel\App_Data\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Reservation WHERE reservation_id IS NOT NULL AND status IS NOT NULL AND price IS NOT NULL";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                connection.Open();
                adapter.Fill(dataTable);
                Repeater1.DataSource = dataTable;
                Repeater1.DataBind();
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string searchReservationId = txtSearch.Text.Trim();

            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Hotel\App_Data\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query;

                if (string.IsNullOrEmpty(searchReservationId))
                {
                    query = "SELECT * FROM Reservation WHERE reservation_id IS NOT NULL";
                }
                else
                {
                    // If search is not empty, filter by reservation_id
                    query = "SELECT * FROM Reservation WHERE reservation_id = @ReservationId AND reservation_id IS NOT NULL";
                }

                SqlCommand command = new SqlCommand(query, connection);

                if (!string.IsNullOrEmpty(searchReservationId))
                {
                    command.Parameters.AddWithValue("@ReservationId", searchReservationId);
                }

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                connection.Open();
                adapter.Fill(dataTable);
                Repeater1.DataSource = dataTable;
                Repeater1.DataBind();
            }
        }
        private void UpdateReservationStatus(int reservationId, bool newStatus)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Hotel\App_Data\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Reservation SET status = @NewStatus WHERE reservation_id = @ReservationId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NewStatus", newStatus);
                command.Parameters.AddWithValue("@ReservationId", reservationId);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
        protected void ReservationCommand_Click(object sender, CommandEventArgs e)
        {
            int reservationId = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case "CheckIn":
                    // Handle check-in logic and update the status to 1
                    UpdateReservationStatus(reservationId, true);
                    break;

                case "CheckOut":
                    Session["reservationid"] = reservationId;
                    UpdateReservationStatusToNull(reservationId);
                    GenerateBill(reservationId);
                    break;

                case "Cancel":
                    RemoveReservation(reservationId);
                    break;
            }
            BindReservationData();
        }
        private void RemoveReservation(int reservationId)
        {
            // Delete related records in the Bill table first
            DeleteBillsForReservation(reservationId);

            // Now delete the reservation
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\HOTEL\APP_DATA\HOTEL_DB.MDF;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Reservation WHERE reservation_id = @ReservationId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ReservationId", reservationId);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private void DeleteBillsForReservation(int reservationId)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\HOTEL\APP_DATA\HOTEL_DB.MDF;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Bill WHERE reservation_id = @ReservationId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ReservationId", reservationId);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
        public int GenerateRandomNumber(int minValue, int maxValue)
        {
            Random random = new Random();
            return random.Next(minValue, maxValue + 1);
        }
        private void GenerateBill(int reservationId)
        {
            InsertBillDetails(reservationId);
            Response.Redirect("BillPage.aspx");
        }
        private void InsertBillDetails(int reservationId)
        {
            int id = GenerateRandomNumber(100, 10000);
            Session["BILL"] = id;
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Hotel\App_Data\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Fetch the price associated with the reservationId
                double price = GetReservationPrice(reservationId);

                // Insert the bill details into the Bill table
                string query = "INSERT INTO Bill (bill_id, bill_price, reservation_id) VALUES (@ID, @BillPrice, @ReservationId)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ID", id);
                command.Parameters.AddWithValue("@BillPrice", price);
                command.Parameters.AddWithValue("@ReservationId", reservationId);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private double GetReservationPrice(int reservationId)
        {
            double price = 0.0; // Default value, update accordingly

            // Fetch the price from the Reservation table based on reservationId
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Hotel\App_Data\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT price FROM Reservation WHERE reservation_id = @ReservationId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ReservationId", reservationId);

                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && result != DBNull.Value)
                {
                    price = Convert.ToDouble(result);
                }
            }

            return price;
        }
        private void UpdateReservationStatusToNull(int reservationId)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Hotel\App_Data\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Reservation SET status = NULL WHERE reservation_id = @ReservationId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ReservationId", reservationId);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("report.aspx");
        }
    }
}