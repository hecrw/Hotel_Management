﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel
{
    public partial class reservations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] is null)
            {
                Response.Redirect("login.aspx");
            }
            if (!IsPostBack)
            {
                // Retrieve username from Session
                string username = Session["Username"]?.ToString();

                if (!string.IsNullOrEmpty(username))
                {
                    // Retrieve reservations for the username from the database
                    DataTable reservationsTable = GetReservationsForUsername(username);

                    // Bind reservations to the repeater control
                    ReservationRepeater.DataSource = reservationsTable;
                    ReservationRepeater.DataBind();
                }
            }
        }

        private DataTable GetReservationsForUsername(string username)
        {
            // Replace with your actual database connection string
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM Reservation WHERE username = @username";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable reservationsTable = new DataTable();
                    adapter.Fill(reservationsTable);

                    return reservationsTable;
                }
            }
        }
        protected string GetStatusText(object status)
        {
            if (status != null && status is bool)
            {
                bool statusValue = (bool)status;
                return statusValue ? "Checked In" : "Not Checked In";
            }

            return "Checked Out";
        }
        private DataTable ExecuteQuery(string query)
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True"))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }
            return dataTable;
        }

        protected void CancelReservation_Click(object sender, EventArgs e)
        {
            // Retrieve the reservation ID from the clicked button's CommandArgument
            int reservationId = Convert.ToInt32((sender as Button).CommandArgument);

            // Implement the logic to cancel the reservation and remove it from the table
            string query = $"DELETE FROM Reservation WHERE reservation_id = {reservationId}";
            ExecuteQuery(query);

            // After canceling the reservation, refresh the Repeater
            RefreshReservationRepeater();
        }
        private void RefreshReservationRepeater()
        {
            // Retrieve the username from the session
            string username = Session["Username"]?.ToString();

            // Check if the username is not null
            if (!string.IsNullOrEmpty(username))
            {
                // Call the method to get reservations for the username
                DataTable reservationsTable = GetReservationsForUsername(username);

                // Bind the result to the Repeater
                ReservationRepeater.DataSource = reservationsTable;
                ReservationRepeater.DataBind();
            }
        }
    }
}