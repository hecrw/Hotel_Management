﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.Optimization;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel
{
    public partial class Reservation : System.Web.UI.Page
    {
        public int GenerateRandomNumber(int minValue, int maxValue)
        {
            Random random = new Random();
            return random.Next(minValue, maxValue + 1);
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] is null)
            {
                Response.Redirect("login.aspx");
            }
            // Check if the form is submitted
            if (IsPostBack)
            {
                DateTime checkInDate = DateTime.Parse(checkIn.Text);
                DateTime checkOutDate = DateTime.Parse(checkOut.Text);

                // Retrieve room ID and username from sessions
                int roomId = Convert.ToInt32(Session["roomId"]);
                string username = Session["Username"].ToString();

                // Check for reservation conflicts
                if (!IsReservationConflict(roomId, checkInDate, checkOutDate))
                {
                    // Calculate the price (you might want to implement this based on your logic)
                    float price = GetRoomPrice(roomId);

                    // Insert reservation into the database
                    InsertReservation(username, roomId, checkInDate, checkOutDate, price);
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "key", "openTrailerModel()", true);

                }
                else
                {
                    // Handle reservation conflict
                    ErrorMessageLabel.Text = "This room is already reserved for the selected dates. Please consider the following options:";
                    ErrorMessageLabel.Text += "<br>- Choose different dates.";
                    ErrorMessageLabel.Text += "<br>- Select another available room.";
                    ErrorMessageLabel.Text += "<br>- Contact our support team for assistance.";
                }

            }
        }

        // Function to check for reservation conflicts
        private bool IsReservationConflict(int roomId, DateTime checkIn, DateTime checkOut)
        {
         
            using (SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True"))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM Reservation " +
                               "WHERE room_id = @roomId " +
                               "AND ((arrival_date <= @checkIn AND departure_date >= @checkIn) " +
                               "OR (arrival_date <= @checkOut AND departure_date >= @checkOut))";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@roomId", roomId);
                    command.Parameters.AddWithValue("@checkIn", checkIn);
                    command.Parameters.AddWithValue("@checkOut", checkOut);

                    int conflictCount = (int)command.ExecuteScalar();

                    return conflictCount > 0;
                }
            }
        }
        private void InsertReservation(string username, int roomId, DateTime checkIn, DateTime checkOut, float price)
        {
            // Establish a connection to your database (update the connection string)
            using (SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True"))
            {
                connection.Open();
                int reservationId = GenerateRandomNumber(100, 1000000);
                // Create a SQL command to insert the reservation
                string query = "INSERT INTO Reservation (reservation_id, username, room_id, arrival_date, departure_date, status, price) " +
                               "VALUES (@reservationId, @username, @roomId, @checkIn, @checkOut, 0, @price)";
                IncrementReservationsAndRevenue(price);
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@reservationId", reservationId);
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@roomId", roomId);
                    command.Parameters.AddWithValue("@checkIn", checkIn);
                    command.Parameters.AddWithValue("@checkOut", checkOut);
                    command.Parameters.AddWithValue("@price", price);

                    // Execute the query
                    command.ExecuteNonQuery();
                }
            }
        }
        private float GetRoomPrice(int roomId)
        {
            // Implement your logic to retrieve the room price based on the room ID from the database
            using (SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True"))
            {
                connection.Open();

                string query = "SELECT price FROM Rooms WHERE room_id = @roomId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@roomId", roomId);

                    // Execute the query and return the room price
                    return Convert.ToSingle(command.ExecuteScalar());
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm1.aspx");
        }
        protected void IncrementReservationsAndRevenue(float reservationPrice)
        {
            // Replace with your actual database connection string
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Hotel\App_Data\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Calculate revenue based on the reservation price
                float revenue = reservationPrice;

                // Create a SQL command to update the Report table for all records (assuming no specific rating is considered)
                string query = "UPDATE Report " +
                               "SET reservations = ISNULL(reservations, 0) + 1, " +
                               "    revenue = ISNULL(revenue, 0) + @revenue";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@revenue", revenue);

                    // Execute the query
                    command.ExecuteNonQuery();
                }
            }
        }
    }

}