﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] is null)
            {
                Response.Redirect("login.aspx");
            }
            if (!IsPostBack)
            {
                BindRoomData();
            }
        }

        private void BindRoomData()
        {
            // Replace "YourConnectionString" with your actual database connection string
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Hotel\\App_Data\\Hotel_DB.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT room_id, room_type, price, photo_path FROM Rooms";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        // Bind data to Repeater
                        roomRepeater.DataSource = dt;
                        roomRepeater.DataBind();
                    }
                }
            }
        }
        protected void MyLinkButton_Click(object sender, EventArgs e)
        {
            // Retrieve the data path from the CommandArgument
            var linkButton = (LinkButton)sender;
            string dataPath = linkButton.CommandArgument;

            // Now you have the data path of the image, and you can use it as needed
            // For example, you can store it in a session variable or perform other actions.
            Session["roomId"] = dataPath;

            // Redirect to Reservation.aspx or perform other actions
            Response.Redirect("Reservation.aspx");
        }


        protected void roomRepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
        }
    }
}